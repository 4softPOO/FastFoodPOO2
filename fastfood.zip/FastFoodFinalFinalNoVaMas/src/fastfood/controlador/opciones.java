/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fastfood.controlador;

import fastfood.modelo.Conexion;
import fastfood.vista.*;
import fastfood.modelo.*;

import fastfood.controlador.credito;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;

/**
 *
 * @author Paua
 */
public class opciones {

    public String contraAntigua;
    public String contraVista;
    public String contraNuevaVista1;
    public String contraNuevaVista2;
    public String repetirContra;
    public String telefono;
    public String telefononDB;
    public String direccion;
    public String direccionnDB;
    public String fecha;
    public String nombre;
    public String apellido;
    public String cad;

    private Opciones_server server;

    public opciones() {
        server = new Opciones_server();

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCad() {
        return cad;
    }

    public void setCad(String cad) {
        this.cad = cad;
    }

    public String getContraVista() {
        return contraVista;
    }

    public void setContraVista(String contraVista) {
        this.contraVista = contraVista;
    }

    public String getContraNuevaVista1() {
        return contraNuevaVista1;
    }

    public void setContraNuevaVista1(String contraNuevaVista1) {
        this.contraNuevaVista1 = contraNuevaVista1;
    }

    public String getContraNuevaVista2() {
        return contraNuevaVista2;
    }

    public void setContraNuevaVista2(String contraNuevaVista2) {
        this.contraNuevaVista2 = contraNuevaVista2;
    }

    public String getContraAntigua() {
        return contraAntigua;
    }

    public void setContraAntigua(String contraAntigua) {
        this.contraAntigua = contraAntigua;
    }

    public String getRepetirContra() {
        return repetirContra;
    }

    public void setRepetirContra(String repetirContra) {
        this.repetirContra = repetirContra;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public opciones obtenerDatosDB() throws Exception {
        //Opciones_server server = new Opciones_server();
        opciones retorno1 = server.obtenerDatosDB();
        retorno1.getTelefono();
        retorno1.getDireccion();
        retorno1.getApellido();
        retorno1.getNombre();
        retorno1.getCad();

        return retorno1;
    }

    public void actualizarDatosDB() throws Exception {
        opciones retorno2 = server.obtenerDatosDB();
        if (getContraVista().equals(retorno2.getContraAntigua())) {
            if (getContraNuevaVista1().equals(getContraNuevaVista2())) {
                retorno2.setContraNuevaVista2(getContraNuevaVista2());
                server.actualizarDatosDB(retorno2);
                System.out.println("contraseña y datos actualizados");
            } else {
                System.out.println("contraseña nueva no coincide");
            }
        } else {
            System.out.println("contraseña antigua incorrecta");
        }
        System.out.println(retorno2.getContraAntigua());
        System.out.println(retorno2.getContraNuevaVista2());

    }
}
