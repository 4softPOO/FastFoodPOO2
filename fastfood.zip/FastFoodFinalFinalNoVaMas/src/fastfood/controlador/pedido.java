/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fastfood.controlador;
import fastfood.vista.*;
/**
 *
 * @author Manuel
 */
public class pedido {
    int bebida;
    String sprite="$2200";
    int valSprite=2200;
    String coca = "$2800";
    int valCoca=2800;
    String quatro = "$2500";
    int valQuatro=2500;
    String jugo = "$1800";
    int valJugo=1800;
    int valBebida;
    String valTot;
    
    //-----------------
   
    int Sand1 = 12000;
    int Sand2 = 13500;
    int Sand3 = 18000;
    int Sand4 = 15000;
    
    public pedido(){
    
    
    }
    
    
}
